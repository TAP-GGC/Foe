Starter code for 2 exercises
